from django.core.mail import send_mail
from django.shortcuts import render
from django.http import HttpResponse
import requests,json
from datetime import datetime
from django.shortcuts import render
from django.contrib.auth.models import User,auth
from django.contrib import messages
from django.contrib.auth.decorators import login_required
def function1(request):
    return HttpResponse("<h1>Hello this is HomePage</h1>")
def function2(request):
    return HttpResponse("<h1>Hello this is Vachaspathi 2100032473</h1>")
def function3(request):
    return render(request,"Homepage.html")
def index1(request):
    # if there are no errors the code inside try will execute
    try:
    # checking if the method is POST
        if request.method == 'POST':
            API_KEY = '9064894655d8fe87fde3970ec4dffaa8'
            # getting the city name from the form input
            city_name = request.POST.get('city')
            # the url for current weather, takes city_name and API_KEY
            url = f'https://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={API_KEY}&units=metric'
            # converting the request response to json
            response = requests.get(url).json()
            # getting the current time
            current_time = datetime.now()
            # formatting the time using directives, it will take this format Day, Month Date Year, Current Time
            formatted_time = current_time.strftime("%A, %B %d %Y, %H:%M:%S %p")
            # bundling the weather information in one dictionary
            city_weather_update = {
                'city': city_name,
                'description': response['weather'][0]['description'],
                'icon': response['weather'][0]['icon'],
                'temperature': 'Temperature: ' + str(response['main']['temp']) + ' °C',
                'country_code': response['sys']['country'],
                'wind': 'Wind: ' + str(response['wind']['speed']) + 'km/h',
                'humidity': 'Humidity: ' + str(response['main']['humidity']) + '%',
                'time': formatted_time
            }
        # if the request method is GET empty the dictionary
        else:
            city_weather_update = {}
        context = {'city_weather_update': city_weather_update}
        return render(request, 'home.html', context)
    # if there is an error the 404 page will be rendered
    # the except will catch all the errors
    except:
        return render(request, '404.html')
# Create your views here.
def contactus(request):
    if request.method=="POST":
        firstname=request.POST['firstname']
        lastname=request.POST['lastname']
        email = request.POST['email']
        comment = request.POST['comment']
        tosend=comment+'.....................................................This is just an acknowledgement'
        data=contactus(firstname=firstname,lastname=lastname,email=email,comment=comment)
        data.save()
        send_mail(
            'Thank you for contacting HLI System',
            tosend,
            'gvachaspathignaneswar@gmail.com',
            [email],
            fail_silently=False
        )
        return HttpResponse('<h1><center>Mail Sent</center></h1>')
    else:
        return HttpResponse('<h1><center>Error Occured</center></h1>')

def index(request):
    return render(request, 'index.html')

@login_required(login_url='index')
def about(request):
    return render(request, 'about.html')

@login_required(login_url='index')
def faq(request):
    return render(request, 'faq.html')

def login(request):
    return render(request, 'login.html')

def signup(request):
    return render(request, 'signup.html')

def login1(request):
    if request.method == 'POST':
        username = request.POST['username']
        pass1 = request.POST['password']
        user = auth.authenticate(username=username, password=pass1)
        if user is not None:
            auth.login(request, user)
            return render(request, 'index.html')
        else:
            messages.info(request, 'Invalid credentials')
            return render(request, 'login.html')
    else:
        return render(request, 'login.html')

def signup1(request):
    if request.method == "POST":
        username = request.POST['username']
        pass1 = request.POST['password']
        pass2 = request.POST['password1']
        if pass1 == pass2:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'OOPS! Usename already taken')
                return render(request, 'signup.html')
            else:
                user = User.objects.create_user(username=username, password=pass1)
                user.save()
                messages.info(request, 'Account created successfully!!')
                return render(request, 'login.html')
        else:
            messages.info(request, 'Password do not match')
            return render(request, 'signup.html')

def logout(request):
    auth.logout(request)
    return render(request, 'index.html')