from django.urls import path
from . import views
urlpatterns=[
    path('page/',views.function1, name = 'home'),
    path('id/',views.function2),
    path('home/',views.function3),
    path('wet/',views.index1,name='index1'),
    path('', views.index, name='index'),
    path('login', views.login, name="login"),
    path('login1', views.login1, name="login1"),
    path('signup', views.signup, name="signup"),
    path('signup1', views.signup1, name="signup1"),
    path('about', views.about, name="about"),
    path('faq', views.faq, name="faq"),
    path('logout', views.logout, name="logout"),
]