from django.contrib import admin
from . models import signingup
admin.site.register(signingup)