from django.contrib.sites import requests
from django.core.mail import send_mail
from django.db.models import Q
from django.shortcuts import render
from django.http import HttpResponse
import time,datetime,pyqrcode
from django.contrib import messages

from .forms import HomeForm
from .models import datetime1,contactus, signingup
from django.contrib.auth.models import User,auth
def function1(request):
    return render(request,"index.html")
def function2(request):
    return render(request,"Home.html")
def function3(request):
    return render(request,"about.html")
def function4(request):
    return render(request,"policies.html")
def function5(request):
    return render(request,"claims.html")
def function6(request):
    return render(request,"payment.html")
def function7(request):
    return render(request,"service.html")
def function8(request):
    return render(request,"profile.html")
def function10(request):
    return render(request,"settings.html")
def function11(request):
    return render(request,"help.html")
def function14(request):
     return render(request,"wet.html")
def function9(request):
    var1=time.asctime(time.localtime(time.time()))
    data=datetime1(time12=var1)
    data.save()
    return HttpResponse(var1)
def function12(request):
    s = '''id=2100030615
            name=Radha Yaraguti'''
    url = pyqrcode.create(s)
    url.svg("./static/images/myqr.svg", scale=8)
    return render(request, "qrcd.html")
def contactus1(request):
    if request.method=="POST":
        firstname=request.POST['firstname']
        lastname=request.POST['lastname']
        email = request.POST['email']
        comment = request.POST['comment']
        tosend=comment+'.....................................................This is just an acknowledgement'
        data=contactus(firstname=firstname,lastname=lastname,email=email,comment=comment)
        data.save()
        send_mail(
            'Thank you for contacting AAS System',
            tosend,
            'yradha1694@gmail.com',
            [email],
            fail_silently=False,
        )
        messages.success(request, "Success: This is the sample success Flash message.")
        return render(request, 'service.html')
    else:
        messages.error(request, "Error: This is the sample error Flash message.")
        return render(request,'service.html')
def sign(request):
    if request.method=="POST":
        fname=request.POST['fname']
        lname=request.POST['lname']
        gmail = request.POST['gmail']
        mobile = request.POST['mobile']
        uname = request.POST['uname']
        psswrd = request.POST['psswrd']
        tosend = 'You have successfully Registered'
        sum=signingup(fname=fname,lname=lname,gmail=gmail,mobile=mobile,uname=uname,psswrd=psswrd)
        sum.save()
        send_mail(
            'Thank you for contacting AAS System',
            tosend,
            'yradha1694@gmail.com',
            [gmail],
            fail_silently=False,
        )
        messages.info(request, 'Successfully Registered')
        return render(request, "index.html")
    else:
        messages.info(request, 'Registration Failed')
        return render(request, "index.html")
def checkuserlogin(request):
    un=request.POST["username"]
    pd=request.POST["password"]
    flag=signingup.objects.filter(Q(uname=un) & Q(psswrd=pd))
    print(flag)
    if flag:
        user=signingup.objects.get(uname=un)
        request.session["uname"]=user.uname
        messages.info(request, 'Successfully Logged OUT')
        return render(request,"home.html")
    else:
        messages.info(request, 'Invalid credentials')
        return render(request,"index.html")
def function15(request):
    # if there are no errors the code inside try will execute
    try:
    # checking if the method is POST
        if request.method == 'POST':
            API_KEY = '9064894655d8fe87fde3970ec4dffaa8'
            # getting the city name from the form input
            city_name = request.POST.get('city')
            # the url for current weather, takes city_name and API_KEY
            url = f'https://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={API_KEY}&units=metric'
            # converting the request response to json
            response = requests.get(url).json()
            # getting the current time
            current_time = datetime.now()
            # formatting the time using directives, it will take this format Day, Month Date Year, Current Time
            formatted_time = current_time.strftime("%A, %B %d %Y, %H:%M:%S %p")
            # bundling the weather information in one dictionary
            city_weather_update = {
                'city': city_name,
                'description': response['weather'][0]['description'],
                'icon': response['weather'][0]['icon'],
                'temperature': 'Temperature: ' + str(response['main']['temp']) + ' °C',
                'country_code': response['sys']['country'],
                'wind': 'Wind: ' + str(response['wind']['speed']) + 'km/h',
                'humidity': 'Humidity: ' + str(response['main']['humidity']) + '%',
                'time': formatted_time
            }
            return render(request, 'wet.html')
        # if the request method is GET empty the dictionary
        else:
            city_weather_update = {}
        context = {'city_weather_update': city_weather_update}
        return render(request, 'wet.html', context)
    # if there is an error the 404 page will be rendered
    # the except will catch all the errors
    except:
        return render(request, '404.html')
def index(request):
    return render(request, 'wet.html')
# Create your views here.