from django import forms

class HomeForm(forms.Form):
    OPTIONS = (
        ('name', 'name'),
        ('city', 'city')
    )

    columns = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple,
                                        choices=OPTIONS)